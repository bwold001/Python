import pygame

#from Game import *
from Game.Pets import Pet
from Game.Scenes import *
from Game.Shared import GameConstants

# Main MyVirtualPet Class
class MyVirtualPet:

    def __init__(self):
        self.__pet = Pet(0 ,self)

        pygame.init()
        pygame.mixer.init()
        pygame.display.set_caption("My Virtual Pet")

        self.__GameLoop = True

        self.__clock = pygame.time.Clock()

        self.screen = pygame.display.set_mode(GameConstants.SCREEN_SIZE, pygame.DOUBLEBUF, 32)

        self.__scenes = (
            MainMenuScene(self),
            InsideScene(self),
            OutsideScene(self)
        )

        self.__currentScene = 0

        self.__sounds = ();

        pygame.mixer.music.load(GameConstants.MUSIC_BG)
        pygame.mixer.music.play(1)

    def start(self):
        while self.__GameLoop:
            self.__clock.tick(30)

            self.screen.fill((0,0,0))

            currentScene = self.__scenes[self.__currentScene]
            currentScene.handleEvents(pygame.event.get())
            currentScene.render()

            pygame.display.update()

        pygame.quit()
        quit()


    def setGameLoop(self, val):
        self.__GameLoop = val

    def changeScene(self, scene):
        self.__scenes[scene].__init__(self)
        self.__currentScene = scene

    def playSound(self, soundClip):
        sound = self.__sounds[soundClip]

        sound.play()

    def getPet(self):
        return self.__pet

    def reset(self):
        pass

# Starting the Game
if __name__ == "__main__":
	MyVirtualPet().start()
