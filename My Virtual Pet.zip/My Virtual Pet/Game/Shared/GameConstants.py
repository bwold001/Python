import os

class GameConstants:

    SCREEN_SIZE = (720, 480)
    PET_SIZE = (350, 350)

    SPRITE_MENU_CHOOSE_YOUR_PET = os.path.join("Game", "Assets", "Menu", "choose_your_pet.png")
    SPRITE_MENU_TITLE = os.path.join("Game", "Assets", "Menu", "title.png")
    SPRITE_MENU_CAT = os.path.join("Game", "Assets", "Menu", "cat.png")
    SPRITE_MENU_DOG = os.path.join("Game", "Assets", "Menu", "dog.png")
    SPRITE_MENU_HAMSTER = os.path.join("Game", "Assets", "Menu", "hamster.png")
    SPRITE_MENU_LLAMA = os.path.join("Game", "Assets", "Menu", "llama.png")
    SPRITE_MENU_CLOSE = os.path.join("Game", "Assets", "Menu", "close.png")
    SPRITE_MENU_BG = os.path.join("Game", "Assets", "Menu", "bg.png")

    SPRITE_INSIDE_BG = os.path.join("Game", "Assets", "Inside", "BG.png")
    SPRITE_INSIDE_PETS = [
        os.path.join("Game", "Assets", "Inside", "Cat.png"),
        os.path.join("Game", "Assets", "Inside", "Dog.png"),
        os.path.join("Game", "Assets", "Inside", "Hamster.png"),
        os.path.join("Game", "Assets", "Inside", "Llama.png")
    ]
    SPRITE_INSIDE_FOOD = os.path.join("Game", "Assets", "Inside", "FoodButton.png")
    SPRITE_INSIDE_WASH = os.path.join("Game", "Assets", "Inside", "WashButton.png")
    SPRITE_INSIDE_PLAY = os.path.join("Game", "Assets", "Inside", "PlayButton.png")

    SPRITE_OUTSIDE_BG = os.path.join("Game", "Assets", "Outside", "Outside_BG.png")
    SPRITE_OUTSIDE_TRICKS = os.path.join("Game", "Assets", "Outside", "TricksButton.png")
    SPRITE_OUTSIDE_BACK = os.path.join("Game", "Assets", "Outside", "BackButton.png")

    MUSIC_BG = os.path.join("Game", "Assets", "Sounds", "Music.mp3")

    SOUND_BG = 0;

    FILE_COUNT_ANIMS = [
        3, 4, 4, 8, 5, 4, 4, 4, 4, 6, 4, 3, 7
    ]

    POSITIONS_MENU_SPRITES = [
        (0,0),
        (271, 74),
        (9, 7),
        (19, 198),
        (193, 198),
        (363, 198),
        (532, 175),
        (647, 3)
    ]

    POSITIONS_INSIDE_PETS =[
        (225, 100),
        (234, 86),
        (242, 88),
        (242, 68)
    ]

    POSITIONS_INSIDE_SPRITES = [
        (0, 0),
        POSITIONS_INSIDE_PETS,
        (35, 410),
        (265, 410),
        (495, 410)
    ]

    POSITIONS_OUTSIDE_SPRITES = [
        (0, 0),
        POSITIONS_INSIDE_PETS,
        (20, 410),
        (511, 410)
    ]

    POSITION_INSIDE_ENERGY = (111, 29)
    POSITION_INSIDE_DIRTY = (315, 29)
    POSITION_INSIDE_HAPPY = (571, 29)

    PET_CAT = 0
    PET_DOG = 1
    PET_HAMSTER = 2
    PET_LLAMA = 3

    SCENE_MAINMENU = 0
    SCENE_INSIDE = 1
    SCENE_OUTSIDE = 2

    ANIM_AFFECTION = 0
    ANIM_BARKING = 1
    ANIM_BLINKING = 2
    ANIM_EATING = 3
    ANIM_IDLE = 4
    ANIM_LYINGDOWN = 5
    ANIM_RAISING = 6
    ANIM_SAD = 7
    ANIM_SITTING = 8
    ANIM_SLEEPING = 9
    ANIM_TIRED = 10
    ANIM_NO = 11
    ANIM_TURNING = 12