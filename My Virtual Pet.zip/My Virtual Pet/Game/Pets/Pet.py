
class Pet:

    def __init__(self, name, game):
        self.__name = name
        self.__game = game
        self.__energy = 50
        self.__happiness = 50
        self.__clean = True

    def getGame(self):
        return self.__game

    def setGame(self, game):
        self.__game = game

    def isClean(self):
        return self.__clean

    def setClean(self, clean):
        self.__clean = clean

    def getEnergy(self):
        return self.__energy

    def getHappiness(self):
        return self.__happiness

    def setEnergy(self, energy):
        if energy >= 0 and energy <= 100:
            self.__energy = energy
        elif energy > 100:
            self.__energy = 100
        elif energy < 0:
            self.__energy = 0

    def setHappiness(self, happiness):
        if happiness >= 0 and happiness <= 100:
            self.__happiness = happiness
        elif happiness > 100:
            self.__happiness = 100
        elif happiness < 0:
            self.__happiness = 0

    def getName(self):
        return self.__name

    def setName(self, name):
        self.__name = name
