
from Game.MyVirtualPet import MyVirtualPet