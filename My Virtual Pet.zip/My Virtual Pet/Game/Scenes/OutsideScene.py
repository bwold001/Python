import pygame, os
from Game.Shared.pyganim import *
from Game.Shared.MySprite import MySprite
from Game.Shared.GameConstants import GameConstants
from Game.Scenes.Scene import Scene

class OutsideScene(Scene):
    
    def __init__(self, game):
        super(OutsideScene, self).__init__(game)

        self.petNames = [
            "Cat",
            "Dog",
            "Hamster",
            "Llama"
        ]

        self.animations = [
            "Affection",
            "Barking",
            "Blinking",
            "Eating",
            "Idle",
            "LyingDown",
            "Raising",
            "Sad",
            "Sitting",
            "Sleeping",
            "Tired",
            "TongueNo",
            "Turning"
        ]

        self.petNo = game.getPet().getName()

        self.__pet = game.getPet()
        self.__sprites = [
            MySprite(pygame.image.load(GameConstants.SPRITE_OUTSIDE_BG), 0),
            MySprite(pygame.image.load(GameConstants.SPRITE_INSIDE_PETS[self.getGame().getPet().getName()]), 1),
            MySprite(pygame.image.load(GameConstants.SPRITE_OUTSIDE_TRICKS), 1),
            MySprite(pygame.image.load(GameConstants.SPRITE_OUTSIDE_BACK), 1)
        ]

        for i in range(0, 4):
            if i == 1:
                #Pet
                self.__sprites[i].rect.x = GameConstants.POSITIONS_INSIDE_SPRITES[i][self.getGame().getPet().getName()][0]
                self.__sprites[i].rect.y = GameConstants.POSITIONS_INSIDE_SPRITES[i][self.getGame().getPet().getName()][1]
                continue
            self.__sprites[i].rect.x = GameConstants.POSITIONS_OUTSIDE_SPRITES[i][0]
            self.__sprites[i].rect.y = GameConstants.POSITIONS_OUTSIDE_SPRITES[i][1]

        self.loadedAnimations = []

        for i in range (0, 13):
            temp = []
            DIR = os.path.join("Game", "Assets", "Inside", self.petNames[self.petNo], self.animations[i])
            for name in os.listdir(DIR):
                if os.path.isfile(os.path.join(DIR, name)):
                    temp.append((os.path.join(DIR, name), 0.3))
            self.loadedAnimations.append(PygAnimation(temp))

        self.currentAnim = GameConstants.ANIM_BLINKING
        self.performAction(1)
        self.animChange = 0


    def handleEvents(self, events):
        super(OutsideScene, self).handleEvents(events)

        for event in events:
            if event.type == pygame.QUIT:
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                for i in range(0, 4):
                    if self.__sprites[i].is_clicked():
                        self.performAction(i)
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_ESCAPE:
                    self.getGame().changeScene(GameConstants.SCENE_MAINMENU)

    def performAction(self, i):
        if i == 1:
            # Pet
            if self.__pet.getHappiness() > 30 and self.__pet.getHappiness() < 70:
                if self.__pet.getEnergy() > 40:
                    if self.currentAnim == GameConstants.ANIM_BLINKING:
                        self.currentAnim = GameConstants.ANIM_IDLE
                        self.loadedAnimations[self.currentAnim].play()
                    else:
                        self.currentAnim = GameConstants.ANIM_BLINKING
                        self.loadedAnimations[self.currentAnim].play()
                elif self.__pet.getEnergy() > 30:
                    self.currentAnim = GameConstants.ANIM_SITTING
                    self.loadedAnimations[self.currentAnim].play()
                elif self.__pet.getEnergy() > 20:
                    self.currentAnim = GameConstants.ANIM_LYINGDOWN
                    self.loadedAnimations[self.currentAnim].play()
                elif self.__pet.getEnergy() <= 20:
                    self.currentAnim = GameConstants.ANIM_TIRED
                    self.loadedAnimations[self.currentAnim].play()
            elif self.__pet.getHappiness() > 70:
                if self.__pet.getEnergy() > 40:
                    if self.__pet.getEnergy() > 70:
                        if self.__pet.getHappiness() > 90:
                            self.currentAnim = GameConstants.ANIM_RAISING
                            self.loadedAnimations[self.currentAnim].play()
                        if self.__pet.getHappiness() > 80:
                            self.currentAnim = GameConstants.ANIM_BARKING
                            self.loadedAnimations[self.currentAnim].play()
                    else:
                        self.currentAnim = GameConstants.ANIM_AFFECTION
                        self.loadedAnimations[self.currentAnim].play()
                elif self.__pet.getEnergy() > 30:
                    self.currentAnim = GameConstants.ANIM_SITTING
                    self.loadedAnimations[self.currentAnim].play()
                elif self.__pet.getEnergy() > 20:
                    self.currentAnim = GameConstants.ANIM_LYINGDOWN
                    self.loadedAnimations[self.currentAnim].play()
                elif self.__pet.getEnergy() <= 20:
                    self.currentAnim = GameConstants.ANIM_TIRED
                    self.loadedAnimations[self.currentAnim].play()
            elif self.__pet.getHappiness() < 30:
                if self.__pet.getEnergy() > 20:
                    self.currentAnim = GameConstants.ANIM_SAD
                    self.loadedAnimations[self.currentAnim].play()
                elif self.__pet.getEnergy() <= 20:
                    self.currentAnim = GameConstants.ANIM_TIRED
                    self.loadedAnimations[self.currentAnim].play()
        if i == 2:
            # Tricks
            if self.__pet.getEnergy() > 20:
                self.currentAnim = GameConstants.ANIM_TURNING
                self.loadedAnimations[self.currentAnim].play()
                self.__pet.setEnergy(self.__pet.getEnergy() - 15)
                self.__pet.setHappiness(self.__pet.getHappiness() + 5)
                self.__pet.setClean(False)
            else:
                self.currentAnim = GameConstants.ANIM_NO
                self.loadedAnimations[self.currentAnim].play()
        if i == 3:
            # Back
            self.getGame().changeScene(GameConstants.SCENE_INSIDE)


    def render(self):
        game = self.getGame()

        if self.animChange == 270:
            self.animChange = 0
            self.performAction(1)

        for i in range(0, 4):
            if i == 1:
                #Pet
                #game.screen.blit(self.__sprites[i].image, GameConstants.POSITIONS_INSIDE_SPRITES[i][self.getGame().getPet().getName()])
                continue
            game.screen.blit(self.__sprites[i].image, GameConstants.POSITIONS_OUTSIDE_SPRITES[i])

        self.clearText()
        self.addText(str(self.__pet.getEnergy())+" / 100", GameConstants.POSITION_INSIDE_ENERGY[0], GameConstants.POSITION_INSIDE_ENERGY[1], (25,123,48), (235,235,235))
        self.addText(str(self.__pet.getHappiness())+" / 100", GameConstants.POSITION_INSIDE_HAPPY[0], GameConstants.POSITION_INSIDE_HAPPY[1], (0,74,128), (188,211,238))
        if self.__pet.isClean():
            self.addText("CLEAN", GameConstants.POSITION_INSIDE_DIRTY[0], GameConstants.POSITION_INSIDE_DIRTY[1], (237,20,91), (246,199,201))
        else:
            self.addText("DIRTY", GameConstants.POSITION_INSIDE_DIRTY[0], GameConstants.POSITION_INSIDE_DIRTY[1], (237,20,91), (246,199,201))

        self.loadedAnimations[self.currentAnim].blit(game.screen, GameConstants.POSITIONS_INSIDE_SPRITES[1][self.getGame().getPet().getName()])
        self.animChange = self.animChange + 1
        super(OutsideScene, self).render()

