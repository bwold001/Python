import pygame
from Game.Shared import *
from Game.Scenes.Scene import Scene

class MainMenuScene(Scene):
    
    def __init__(self, game):
        super(MainMenuScene, self).__init__(game)
        self.__sprites = [
            MySprite(pygame.image.load(GameConstants.SPRITE_MENU_BG), False),
            MySprite(pygame.image.load(GameConstants.SPRITE_MENU_CHOOSE_YOUR_PET), False),
            MySprite(pygame.image.load(GameConstants.SPRITE_MENU_TITLE), False),
            MySprite(pygame.image.load(GameConstants.SPRITE_MENU_CAT), True),
            MySprite(pygame.image.load(GameConstants.SPRITE_MENU_DOG), True),
            MySprite(pygame.image.load(GameConstants.SPRITE_MENU_HAMSTER), True),
            MySprite(pygame.image.load(GameConstants.SPRITE_MENU_LLAMA), True),
            MySprite(pygame.image.load(GameConstants.SPRITE_MENU_CLOSE), True)
        ]

        for i in range(0, 8):
            self.__sprites[i].rect.x = GameConstants.POSITIONS_MENU_SPRITES[i][0]
            self.__sprites[i].rect.y = GameConstants.POSITIONS_MENU_SPRITES[i][1]

    def handleEvents(self, events):
        super(MainMenuScene, self).handleEvents(events)

        for event in events:
            if event.type == pygame.QUIT:
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                for i in range(0, 8):
                    if self.__sprites[i].is_clicked():
                        self.performAction(i)


    def performAction(self, i):
        if i == 3:
            # Cat
            self.getGame().getPet().setName(GameConstants.PET_CAT)
            self.getGame().changeScene(GameConstants.SCENE_INSIDE)
        elif i == 4:
            # Dog
            self.getGame().getPet().setName(GameConstants.PET_DOG)
            self.getGame().changeScene(GameConstants.SCENE_INSIDE)
        elif i == 5:
            # Hamster
            self.getGame().getPet().setName(GameConstants.PET_HAMSTER)
            self.getGame().changeScene(GameConstants.SCENE_INSIDE)
        elif i == 6:
            # Llama
            self.getGame().getPet().setName(GameConstants.PET_LLAMA)
            self.getGame().changeScene(GameConstants.SCENE_INSIDE)
        elif i == 7:
            # Close
            self.getGame().setGameLoop(False)


    def render(self):
        super(MainMenuScene, self).render()

        game = self.getGame()
        for i in range(0, 8):
            game.screen.blit(self.__sprites[i].image, GameConstants.POSITIONS_MENU_SPRITES[i])

