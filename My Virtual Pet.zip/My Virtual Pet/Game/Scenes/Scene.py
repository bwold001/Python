import pygame

class Scene:

    def __init__(self, game):
        self.__game = game
        self.__texts = []
        self.LucidaFont = pygame.font.SysFont("Lucida Console", 20)

    def render(self):
        for text in self.__texts:
            self.__game.screen.blit(text[0], text[1])

    def getGame(self):
        return self.__game

    def handleEvents(self, events):
        pass

    def clearText(self):
        self.__texts = []

    def addText(self, string, x=0, y=0, color = [255,255,255], background = [0,0,0], size = 17):
        text = self.LucidaFont.render(string, True, color, background)
        self.__texts.append([text, (x,y)])