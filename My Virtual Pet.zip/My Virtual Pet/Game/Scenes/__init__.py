from Game.Scenes.Scene import Scene
from Game.Scenes.InsideScene import InsideScene
from Game.Scenes.OutsideScene import OutsideScene
from Game.Scenes.MainMenuScene import MainMenuScene