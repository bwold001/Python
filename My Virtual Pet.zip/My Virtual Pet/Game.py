from Game import *

MyVirtualPet().start()
